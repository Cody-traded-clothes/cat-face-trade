---
name: '📈 Enhancement'
about: Enhancement to our codebase that isn't a adding or changing a feature
labels: 'Type: Enhancement 📈'
---

## Overview/summary

<!-- Write a short description of the enhancement here ↓ -->

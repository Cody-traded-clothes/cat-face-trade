---
title: A new release of the Shopify API occurred
labels: automated
---

This is an automated reminder for the maintainers that a new Stable release of the Shopify API is scheduled for today
at 12pm Eastern Time, so a new release of the library is now due.

A draft PR should already exist for this.

Review the changelog again and consider if anything in the library needs to change:

https://shopify.dev/changelog

Test against the new release by using the Stable version just released.

Aim to release an update of the library within one week.

Thank you!

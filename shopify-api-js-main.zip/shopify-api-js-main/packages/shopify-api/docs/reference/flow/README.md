# shopify.flow

This object contains functions used to authenticate Flow extension requests coming from Shopify.

| Property                  | Description                                                         |
| ------------------------- | ------------------------------------------------------------------- |
| [validate](./validate.md) | Verify whether a request is a valid Shopify Flow extension request. |

[Back to shopifyApi](../shopifyApi.md)

export {graphqlClientClass, GraphqlClient} from './graphql/client';
export {restClientClass, RestClient} from './rest/client';

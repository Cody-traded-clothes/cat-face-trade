export {StorefrontClient, storefrontClientClass} from './client';

export type LogContext = Record<string, any>;

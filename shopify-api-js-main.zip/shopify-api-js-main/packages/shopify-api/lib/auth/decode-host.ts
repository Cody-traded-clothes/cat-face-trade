export function decodeHost(host: string): string {
  return atob(host);
}

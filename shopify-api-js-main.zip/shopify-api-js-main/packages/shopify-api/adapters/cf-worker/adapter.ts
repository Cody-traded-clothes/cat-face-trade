export function workerRuntimeString(): string {
  return 'Cloudflare worker';
}

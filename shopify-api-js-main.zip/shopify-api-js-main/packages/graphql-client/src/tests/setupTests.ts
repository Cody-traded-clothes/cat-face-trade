import "regenerator-runtime/runtime";
import { enableFetchMocks } from "jest-fetch-mock";

enableFetchMocks();

# Changelog

## 0.0.6

### Patch Changes

- dba2232: Bumps @graphql-codegen/cli from 5.0.0 to 5.0.2.
- edb4bb0: Bumps @parcel/watcher from 2.4.0 to 2.4.1.

## 0.0.5

### Patch Changes

- 8e06306: Replaced @shopify/hydrogen-codegen with its more generic successor, @shopify/graphql-codegen. All of the changes are internal, so this package is unchanged.

## 0.0.4

### Patch Changes

- 37f1b7b: Updated dependency on @shopify/hydrogen-codegen

## 0.0.3

### Patch Changes

- e10395ca: Update @graphql-codegen/typescript from 4.0.1 to 4.0.4.

## 0.0.2

### Patch Changes

- 6ed8499a: Update @shopify/hydrogen-codegen from 0.1.0 to 0.2.0.
- 284f2cf2: Update @parcel/watcher from 2.3.0 to 2.4.0.

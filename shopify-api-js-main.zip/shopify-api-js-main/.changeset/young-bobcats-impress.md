---
'@shopify/shopify-api': minor
---

Add a context argument to webhooks process function to make it easier for Cloudflare apps (and others that might use a context object) to pass information to the handler.
